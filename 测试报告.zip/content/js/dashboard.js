/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.0061162079510703364, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "HTTP请求 - 搜索商品"], "isController": false}, {"data": [0.012455516014234875, 500, 1500, "HTTP请求 - 登录"], "isController": false}, {"data": [0.0, 500, 1500, "事务控制器 - 查看购物车"], "isController": true}, {"data": [0.0, 500, 1500, "HTTP请求 - 下订单"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP请求 - 查看我的订单"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP请求 - 加入购物车"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP请求 - 获取首页数据"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP请求- 查看购物车"], "isController": false}, {"data": [0.0, 500, 1500, "事务控制器 - 加入购物车"], "isController": true}, {"data": [0.0, 500, 1500, "事务控制器 - 查看订单"], "isController": true}, {"data": [0.009259259259259259, 500, 1500, "HTTP请求 - 获取商品详情"], "isController": false}, {"data": [0.0, 500, 1500, "事务控制器 - 业务流程"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP请求 - 去结算"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 579, 0, 0.0, 28463.18825561312, 719, 73500, 21318.0, 65176.0, 70948.0, 73178.40000000001, 7.725665488024551, 28.051925578757757, 2.6922738132964175], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["HTTP请求 - 搜索商品", 37, 0, 0.0, 38263.43243243243, 21318, 65701, 36228.0, 54201.20000000003, 65443.6, 65701.0, 0.4997568750337673, 0.8282103680979523, 0.11664247376276406], "isController": false}, {"data": ["HTTP请求 - 登录", 281, 0, 0.0, 17777.295373665496, 719, 40363, 17455.0, 29532.800000000003, 32568.199999999997, 39427.58, 3.9559635094042123, 1.8312059177553779, 0.9635017052173669], "isController": false}, {"data": ["事务控制器 - 查看购物车", 19, 0, 0.0, 29946.736842105263, 14550, 58979, 28554.0, 46063.0, 58979.0, 58979.0, 0.2789686967757092, 0.3026701387869266, 0.1847077894667293], "isController": true}, {"data": ["HTTP请求 - 下订单", 8, 0, 0.0, 7155.625, 4617, 12095, 7030.5, 12095.0, 12095.0, 12095.0, 0.29152394140368776, 0.059785183295678154, 0.16540567378470958], "isController": false}, {"data": ["HTTP请求 - 查看我的订单", 35, 0, 0.0, 46309.22857142858, 13961, 71208, 47642.0, 63394.19999999998, 71015.2, 71208.0, 0.48395348515645525, 1.9828724756640534, 0.21692836883477828], "isController": false}, {"data": ["HTTP请求 - 加入购物车", 56, 0, 0.0, 25606.28571428571, 6755, 50514, 22168.0, 39352.00000000001, 45738.549999999996, 50514.0, 0.7865831390285698, 0.13596212461724302, 0.3848419459505014], "isController": false}, {"data": ["HTTP请求 - 获取首页数据", 35, 0, 0.0, 61554.657142857126, 14873, 73500, 71834.0, 73274.8, 73404.8, 73500.0, 0.4673396357421354, 5.266698629359611, 0.08351870443438551], "isController": false}, {"data": ["HTTP请求- 查看购物车", 19, 0, 0.0, 15603.631578947368, 6480, 32748, 13831.0, 31906.0, 32748.0, 32748.0, 0.282313784341986, 0.1778246004888486, 0.11882543071425387], "isController": false}, {"data": ["事务控制器 - 加入购物车", 26, 0, 0.0, 45044.46153846154, 22479, 68441, 46731.0, 63612.5, 67225.09999999999, 68441.0, 0.3608655220752543, 0.23012225187025495, 0.26465821003761325], "isController": true}, {"data": ["事务控制器 - 查看订单", 30, 0, 0.0, 71080.76666666665, 65621, 72635, 71642.5, 72427.5, 72579.45, 72635.0, 0.41172030467302545, 1.915866456803678, 0.28345978007273726], "isController": true}, {"data": ["HTTP请求 - 获取商品详情", 54, 0, 0.0, 37902.129629629635, 1123, 71603, 34938.5, 66218.0, 68264.5, 71603.0, 0.7442629729170973, 17.360536834125835, 0.14245658465991315], "isController": false}, {"data": ["事务控制器 - 业务流程", 30, 0, 0.0, 67558.43333333332, 62908, 73152, 67343.5, 72593.7, 72885.8, 73152.0, 0.4099200655872105, 0.8776986404317825, 0.5554069951151192], "isController": false}, {"data": ["HTTP请求 - 去结算", 24, 0, 0.0, 18027.041666666668, 4256, 33087, 17254.5, 28930.0, 32142.0, 33087.0, 0.44163921756251956, 0.47856827811309643, 0.21780059069245347], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 579, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
